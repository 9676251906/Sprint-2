/*import { Routes, RouterModule } from "@angular/router";
import { ShowAccountComponent } from './show-account/show-account.component';
import { AddAccountComponent } from './add-account/add-account.component';
import { UpdateAccountComponent } from './update-account/update-account.component';
import { DeleteAccountComponent } from './delete-account/delete-account.component';
import { NgModule } from '@angular/core';
import { AppComponent } from '../app.component';

const routes:Routes=[{path:'showacc',component:ShowAccountComponent},
{path:'addacc',component:AddAccountComponent},
{path:'updacc',component:UpdateAccountComponent},
{path:'delacc',component:DeleteAccountComponent},
{path:'back',component:AppComponent},
{path:'',component:AddAccountComponent},
{path:'**',component:AddAccountComponent}
];
@NgModule({
    imports:[RouterModule.forRoot(routes)],
    exports:[RouterModule]
})
export class AccountRoutingModule{

}*/