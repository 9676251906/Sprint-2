import { Injectable } from "@angular/core";
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Account } from './account';
@Injectable({
    providedIn:'root'
})
export class AccountService
{
    public constructor(private httpClient:HttpClient){ }

    public showAccount(accountId:number) :Observable<any>
    {
        return this.httpClient.get<any>('http://localhost:8090/getAccount/'+accountId);
    }

    public addAccount(account:Account):any
    {
        alert("Account Created");
        return this.httpClient.post<any>('http://localhost:8090/addAccount',account);
    }

    public updateAccount(account:Account):any
    {
        alert("Account Updated");
        return this.httpClient.put<any>('http://localhost:8090/updateAccount',account);
    }

    public deleteAccount(accountId:number):any
    {
        alert("Account deleted")
        return this.httpClient.delete<any>('http://localhost:8090/deleteAccount/'+accountId);
    }

}