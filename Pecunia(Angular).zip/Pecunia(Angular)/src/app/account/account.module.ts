import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AccountComponent } from './account.component';
import { AccountService } from './account-service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; 
import { UpdateAccountComponent } from './update-account/update-account.component';
import { AddAccountComponent } from './add-account/add-account.component';
import { DeleteAccountComponent } from './delete-account/delete-account.component';
import { ShowAccountComponent } from './show-account/show-account.component';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from '../app-routing.module';
@NgModule({
  
   declarations: [
    AccountComponent,
    UpdateAccountComponent,
    AddAccountComponent,
    DeleteAccountComponent,
    ShowAccountComponent
  ],
 
   imports: [
    HttpClientModule,  CommonModule,FormsModule ,RouterModule,AppRoutingModule ],
  
   providers: [ AccountService ],
    bootstrap:[AccountComponent],
   exports: [ AccountComponent , UpdateAccountComponent,
    AddAccountComponent,
    DeleteAccountComponent,
    ShowAccountComponent ]
})
export class AccountModule
{
}