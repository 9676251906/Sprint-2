import { Customer } from './customer';
export class Account
{
    accountId:number;
    customer:Customer;
    openingDate:Date;
    status:String;
    type:String;
    balance:number; 
    public constructor(accountId:number,customer:Customer,openingDate:Date,status:String,type:String,balance:number)  
    {
        this.accountId=accountId;
        this.customer=customer;
        this.openingDate=this.openingDate;
        this.status=status;
        this.type=type;
        this.balance=balance;
    }
}