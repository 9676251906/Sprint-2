import { Component, OnInit } from '@angular/core';
import { Account } from '../account';
import { AccountService } from "../account-service"
import { Customer } from '../customer';
import { Address } from '../address';
@Component({
  selector: 'app-add-account',
  templateUrl: './add-account.component.html',
  styleUrls: ['./add-account.component.css']
})
export class AddAccountComponent implements OnInit 
{
  account:Account=new Account(0,new Customer(0,'','',new Address(0,'','','','','',0),0,'',0),null,'','',0);
  public constructor(private accountService:AccountService) { }

  public addAccount():void
  {
    this.accountService.addAccount(this.account).subscribe();
  }
  ngOnInit(): void {
  }

}
