export class Address
{
    addressId:number;
    hNo:String;
    street:String;
    city:String;
    state:String;
    country:String;
    zipCode:number;
    public constructor(addressId:number,hNo:String,street:String,city:String,state:String,country:String,zipCode:number)
    {
        this.addressId=addressId;
        this.hNo=hNo;
        this.street=street;
        this.city=city;
        this.state=state;
        this.country=country;
        this.zipCode=zipCode;
    }
}
