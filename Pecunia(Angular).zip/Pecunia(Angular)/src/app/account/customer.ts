import { Address } from './address';
export class Customer
{
    customerId:number;
    name:String;
    pan:String;
    address:Address;
    phone:number;
    emailId:String;
    aadharNo:number;
    public constructor(customerId:number,name:String,pan:String,address:Address,phone:number,emailId:String,aadharNo:number)
    {
        this.customerId=customerId;
        this.name=name;
        this.pan=pan;
        this.address=address;
        this.phone=phone;
        this.emailId=emailId;
        this.aadharNo=aadharNo;
    }
}
