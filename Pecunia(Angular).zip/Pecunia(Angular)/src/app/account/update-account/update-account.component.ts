import { Component, OnInit } from '@angular/core';
import { Account } from '../account';
import { Customer } from '../customer';
import { Address } from '../address';
import { AccountService } from '../account-service';
@Component({
  selector: 'app-update-account',
  templateUrl: './update-account.component.html',
  styleUrls: ['./update-account.component.css']
})
export class UpdateAccountComponent implements OnInit 
{

  account:Account=new Account(0,new Customer(0,'','',new Address(0,'','','','','',0),0,'',0),null,'','',0);
  public constructor(private accountService:AccountService) { }

  public updateAccount():void
  {
    this.accountService.updateAccount(this.account).subscribe();
  }

  public showAccount():void
  {
    this.accountService.showAccount(this.account.accountId).subscribe(data=>this.account=data);
  }
  ngOnInit(): void 
  {
  }

}
