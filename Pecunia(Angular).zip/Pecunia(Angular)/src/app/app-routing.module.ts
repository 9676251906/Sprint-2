import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowAccountComponent } from './account/show-account/show-account.component';
import { AddAccountComponent } from './account/add-account/add-account.component';
import { UpdateAccountComponent } from './account/update-account/update-account.component';
import { DeleteAccountComponent } from './account/delete-account/delete-account.component';
import { AppComponent } from './app.component';
const routes: Routes = [{path:'showacc',component:ShowAccountComponent},
{path:'addacc',component:AddAccountComponent},
{path:'updacc',component:UpdateAccountComponent},
{path:'delacc',component:DeleteAccountComponent},
{path:'back',component:AppComponent},
{path:'',redirectTo:'/addacc',pathMatch:'full'}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }