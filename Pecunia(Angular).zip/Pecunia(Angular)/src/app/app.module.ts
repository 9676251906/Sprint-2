import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AccountComponent } from './account/account.component';
import { RouterModule } from '@angular/router';
//import { AccountRoutingModule } from './account/account-routing.module';
import { AccountModule } from './account/account.module';
@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,CommonModule,FormsModule,RouterModule,AccountModule
  ],
  providers: [],
  bootstrap: [AppComponent]   
})
export class AppModule { }
